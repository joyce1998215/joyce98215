import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import processing.serial.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class joyceZ_marine_relax extends PApplet {



Serial port;

int Sensor;  
int IBI;  
int BPM;
PImage imgOne;
PFont font;
ArrayList fish = new ArrayList();
ArrayList fishTwo = new ArrayList();
ArrayList fishThree = new ArrayList();
ArrayList fishFour = new ArrayList();
ArrayList fishFive = new ArrayList();
boolean beat = false;
int heart = 0;   

public void setup() { 
  port = new Serial(this, "COM3", 115200);  
  port.clear();
  port.bufferUntil('\n'); 
  
  
  imgOne = loadImage("marine-background-1.jpg");

  font=  createFont("Ostrich Sans Medium", 120);
  textShow();
  for (int n = 0; n<20; n++) {
    fish.add(new fish());
  }
  for (int m = 0; m<26; m++) {
    fishTwo.add(new fishTwo());
  }
  for (int k = 0; k<5; k++) {
    fishThree.add(new fishThree());
  }
  for (int a = 0; a<15; a++) {
    fishFour.add(new fishFour());
  }
  for (int j = 0; j<35; j++) {
    fishFive.add(new fishFive());
  }
}



public void draw() {
  background(imgOne);
  fill(255, 225);
  textAlign(CENTER, CENTER);
  textFont(font, 40);
  text(BPM + "  B P M ", 1700, 50);
  textShow();
  noStroke();
  fill(38, 83, 138, 120);
  for (int i = 0; i < fish.size(); i++) {
    fish f = (fish) fish.get(i);
    f.draw();
    f.boundaries();
  }//fish_1

    if (BPM<120) {
      fill(193, 144, 200, random(100, 140));
      for (int i = 0; i < fishTwo.size(); i++) {
        fishTwo f = (fishTwo) fishTwo.get(i);
        f.draw();
        f.boundaries();
      }//fish_2
      if (BPM<100) {
        fill(28, 75, 101, 90);
        for (int i = 0; i < fishThree.size(); i++) {
          fishThree f = (fishThree) fishThree.get(i);
          f.draw();
          f.boundaries();
        }//fish_3
        if (BPM<90 ) {
          fill(201, 65, 67, random(120, 150));
          for (int i = 0; i < fishFour.size(); i++) {
            fishFour f = (fishFour) fishFour.get(i);
            f.draw();
            f.boundaries();
          }//fish_4
          if (BPM<78) {
            fill(249, 228, 171, 140);
            for (int i = 0; i < fishFive.size(); i++) {
              fishFive f = (fishFive) fishFive.get(i);
              f.draw();
              f.boundaries();
            }//fish_5
          }
        }
      }
    }
  }



public void textShow() {
  if (BPM<78) {
    fill(255, 225);
    textAlign(CENTER, CENTER);
    textFont(font, 90);
    text("C O N G R A T U L A T I O N S !", width/2, height/2-70);
  } else {
    fill(255, 225);
    textAlign(CENTER, CENTER);
    textFont(font);
    text(" R   E   L   A   X ", width/2, height/2-70);
    textFont(font, 40);
    text("and wait for the changes", width/2, height/2+20);
  }
}

class fish {//the blue fishes
  PVector loc;
  PVector vel;
  float s = random(-90, 90);
  float d = random(0.01f, 0.15f);
  fish() {
    loc = new PVector(random(width), random(height));
    vel = new PVector(random(-1, 1), random(-1, 1));
  }

  public void draw() {
    loc.add(vel);
    pushMatrix();
    translate(loc.x, loc.y);
    scale(d);
    rotate(PI/2.0f);
    beginShape();
    for (int i = 0; i <= 180; i+=20) {
      float x = sin(radians(i)) * i/3;
      float angle = sin(radians(i+s+frameCount*5)) * 50;
      vertex(x-angle, i*2);
      vertex(x-angle, i*2);
    }
    endShape();
    popMatrix();
  }
  public void boundaries() {
    if (loc.x < -100) loc.x = width+100;
    if (loc.x > width+100) loc.x = -100;
    if (loc.y < -100) loc.y = height+100;
    if (loc.y > height+100) loc.y = -100;
  }
}
class fishTwo {//the purple fishes
  PVector locTwo;
  PVector velTwo;
  float sTwo = random(-89, 90);
  float dTwo = random(0.01f, 0.3f);
  fishTwo() {
    locTwo = new PVector(random(width), random(height));
    velTwo = new PVector(random(-1, 3), random(-0.5f, 1));
  }

  public void draw() {
    locTwo.add(velTwo);
    pushMatrix();
    translate(locTwo.x, locTwo.y);
    scale(dTwo);
    rotate(PI/3.0f);
    beginShape();
    for (int i = 0; i <= 180; i+=20) {
      float x = cos(radians(i)) * i/4;
      float angle = cos(radians(i+sTwo+frameCount*5)) * 50;
      vertex(x-angle, i*3);
      vertex(x-angle, i*2);
    }
    endShape();
    popMatrix();
  }
  public void boundaries() {
    if (locTwo.x < -100) locTwo.x = width+100;
    if (locTwo.x > width+100) locTwo.x = -100;
    if (locTwo.y < -100) locTwo.y = height+100;
    if (locTwo.y > height+100) locTwo.y = -100;
  }
}
class fishThree {//the fishes
  PVector locThree;
  PVector velThree;
  float sThree = random(-30, 50);
  float dThree = random(0.05f, 0.2f);
  fishThree() {
    locThree = new PVector(random(width), random(height));
    velThree = new PVector(random(-0.5f, 2), random(0, 1));
  }

  public void draw() {
    locThree.add(velThree);
    pushMatrix();
    translate(locThree.x+1, locThree.y-10);
    scale(dThree);
    rotate(PI/4.0f);
    beginShape();
    for (int i = 0; i <= 600; i+=20) {
      float x = sin(radians(20*i)) * i/2;
      float angle = cos(radians(i+sThree+frameCount*3)) * 30;
      vertex(x-angle, i);
      vertex(x-angle-5, i*2);
    }
    endShape();
    popMatrix();
  }
  public void boundaries() {
    if (locThree.x < -100) locThree.x = width+100;
    if (locThree.x > width+100) locThree.x = -100;
    if (locThree.y < -100) locThree.y = height+100;
    if (locThree.y > height+100) locThree.y = -100;
  }
}
class fishFour {//the red fishes
  PVector locFour;
  PVector velFour;
  float s = random(-90, 90);
  float d = random(0.01f, 0.15f);
  fishFour() {
    locFour = new PVector(random(width), random(height));
    velFour = new PVector(random(-1, 1), random(-1, 1));
  }

  public void draw() {
    locFour.add(velFour);
    pushMatrix();
    translate(locFour.x, locFour.y);
    scale(d);
    rotate(PI/2);
    beginShape();
    for (int i = 0; i <= 180; i+=20) {
      float x = sin(radians(i)) * i/3;
      float angle = sin(radians(i+s+frameCount*5)) * 50;
      vertex(x-angle, i*2);
      vertex(x-angle, i*2);
    }
    endShape();
    popMatrix();
  }
  public void boundaries() {
    if (locFour.x < -100) locFour.x = width+100;
    if (locFour.x > width+100) locFour.x = -100;
    if (locFour.y < -100) locFour.y = height+100;
    if (locFour.y > height+100) locFour.y = -100;
  }
}
class fishFive {//the  yellow `fishes
  PVector locFive;
  PVector velFive;
  float sFive = random(-90, 90);
  float dFive = random(0.01f, 0.15f);
  fishFive() {
    locFive = new PVector(random(width), random(height));
    velFive = new PVector(random(-1, 1), random(-0.5f, 1));
  }

  public void draw() {
    locFive.add(velFive);
    pushMatrix();
    translate(locFive.x, locFive.y);
    scale(dFive);
    rotate(PI/2.0f);
    beginShape();
    for (int i = 0; i <= 180; i+=20) {
      float x = cos(radians(i)) * i/3;
      float angle = sin(radians(i*0.5f+sFive+frameCount*2)) * 40;
      vertex(x-angle+1, i*5);
      vertex(x-angle, i*2);
    }
    endShape();
    popMatrix();
  }
  public void boundaries() {
    if (locFive.x < -100) locFive.x = width+100;
    if (locFive.x > width+100) locFive.x = -100;
    if (locFive.y < -100) locFive.y = height+100;
    if (locFive.y > height+100) locFive.y = -100;
  }
}
public void serialEvent(Serial port){
   String inData = new String(port.readBytesUntil('\n'));
   inData = trim(inData);                
   
   
   if (inData.charAt(0) == 'S'){        
     inData = inData.substring(1);        
     Sensor = PApplet.parseInt(inData);                
   }
   if (inData.charAt(0) == 'B'){          
     inData = inData.substring(1);       
     BPM = PApplet.parseInt(inData);                   
     beat = true;                         
     heart = 20;                          
   }
 if (inData.charAt(0) == 'Q'){             
     inData = inData.substring(1);        
     IBI = PApplet.parseInt(inData);                   
   }
}
  public void settings() {  fullScreen(); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "joyceZ_marine_relax" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
